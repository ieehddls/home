package bnc;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;

@WebServlet("/test")
public class Test extends HttpServlet{
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	throws ServletException, IOException{

	}
}
